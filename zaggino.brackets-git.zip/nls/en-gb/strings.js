/*jshint maxlen:false */

define({
    DATE_FORMAT:                           "DD/MM/YYYY HH:mm:ss"
});
